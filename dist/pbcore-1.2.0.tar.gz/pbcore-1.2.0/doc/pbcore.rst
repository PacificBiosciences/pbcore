pbcore package
==============

Subpackages
-----------

.. toctree::

    pbcore.chemistry
    pbcore.data
    pbcore.deprecated
    pbcore.io
    pbcore.model
    pbcore.util

Module contents
---------------

.. automodule:: pbcore
    :members:
    :undoc-members:
    :show-inheritance:
